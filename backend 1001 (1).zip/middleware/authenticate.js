const jwt=require("jsonwebtoken");

const authenticate=(req,res,next)=>{
    const token=req.headers.authorization
    if (token) {
        jwt.verify(token, 'ainjit', (err, decoded) =>{
            if (decoded) {
                next()
            } else {
                res.send("Please login")
            }
        });
            
    } else {
        res.send("Please login")
    }
    
}

module.exports={
    authenticate
}