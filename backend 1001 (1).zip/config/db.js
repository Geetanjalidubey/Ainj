const mongoose=require("mongoose");

const connection=mongoose.connect("")


module.exports={
    connection
}