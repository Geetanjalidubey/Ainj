const express=require("express");
const noteRouter=express.Router();


noteRouter.get("/",(req,res)=>{
    res.send("All notes here")
})
noteRouter.post("/create",(req,res)=>{
    res.send("Note is created")
})
noteRouter.delete("/delete/:id",(req,res)=>{
    res.send("All notes here")
})

module.exports={
    noteRouter
}