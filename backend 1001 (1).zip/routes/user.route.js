const express=require("express");
const { userModel } = require("../models/user.model");
const jwt = require("jsonwebtoken");
const userRouter=express.Router()
const bcrypt = require('bcrypt');

userRouter.get("/",(req,res)=>{
    res.send("Userpage")
})

userRouter.post("/register",async (req,res)=>{
    const {name,email,password}=req.body;
    try {
        bcrypt.hash(password, 5, async(err, hash) =>{
            if(err) res.send({"msg":"Something went wrong","error":err.message})
            else {
                const user = new userModel({name,email,password:hash})
                await user.save();
                res.send("User has been registered")
        }
        });
        
    } catch (err) {
        res.send({"msg":"Something went wrong","error":err.message})
    }
})

userRouter.post("/login",async (req,res)=>{
    const {email,password}=req.body;
    
    try {
        const user = await userModel.find({email})
        if(user.length>0){
            bcrypt.compare(password, user[0].password, (err, result)=> {
                if(result){
                    const token = jwt.sign({ course: 'backend' }, 'ainjit');
                    res.send({"msg":"Login Successful","token":token})
                }else{
                    res.send("Something went wrong")
                }
            });
           
        }else{
            res.send("Something went wrong")
        }
       
    } catch (err) {
        res.send({"msg":"Something went wrong","error":err.message})
    }

})

module.exports={
    userRouter
}